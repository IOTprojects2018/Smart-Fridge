#!/bin/bash
python ProductWS.py & 
wait
