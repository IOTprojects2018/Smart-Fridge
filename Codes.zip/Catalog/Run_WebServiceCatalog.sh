#!/bin/bash
python3 WSCatalog.py & 
python3 delete_client.py &
wait
