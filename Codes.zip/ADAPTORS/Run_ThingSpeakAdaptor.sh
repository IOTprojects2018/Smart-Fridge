#!/bin/bash
python ThingSpeakAdaptor.py &
wait