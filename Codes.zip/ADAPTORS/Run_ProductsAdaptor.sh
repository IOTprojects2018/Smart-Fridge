#!/bin/bash
python ProductsAdaptor.py &
wait