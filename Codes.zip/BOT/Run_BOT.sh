#!/bin/bash
python SmartRefrigerator_bot.py & 
wait
