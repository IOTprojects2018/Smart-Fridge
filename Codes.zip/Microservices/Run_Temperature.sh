#!/bin/bash
python Temperature_Control.py & 
wait
