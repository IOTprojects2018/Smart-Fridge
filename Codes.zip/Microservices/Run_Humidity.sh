#!/bin/bash
python Humidity_Control.py & 
wait
