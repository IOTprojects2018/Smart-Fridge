#!/bin/bash
python Motion_Control.py & 
wait
