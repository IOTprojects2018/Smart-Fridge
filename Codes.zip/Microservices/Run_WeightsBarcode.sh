#!/bin/bash
python WeightsBarcode_Control.py & 
wait
