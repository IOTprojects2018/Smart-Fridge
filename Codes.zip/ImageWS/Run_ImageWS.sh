#!/bin/bash
python3 ImageWebService.py & 
wait
