#!/bin/bash
python3 RaspberryWebService.py &
wait
